#!/usr/bin/python3
#-*-coding:Utf-8-*-
"""
Project isn
"""

# fichier : codepython.py
# Auteur : Tout le groupe 

# pour ISN modifié le 21/04/17

#Prendre scoreequipe1
#Prendre scoreequipe2


Sport  = str(input(" Choisisez le sport sur lequel vous voulez parier  : "))
if /////sport dans la base de donnée:////
    print ("le sport est disponible")
if ////sport pas dans la base de donnée://///
    print ("le sport n'est pas disponible")
equipe1 = str(input(" Choisisez la première équipe des deux qui vont s'affronter : "))
equipe2 = str(input("Choisisez la deuxième équipe : "))

#la base de donnée nous donne les scores des deux équipes.
#scoreequipe1 et scoreequipe2

somme=scoreequipe1+scoreequipe2
intermediaire=100/somme
pourcentage1=intermediaire*scoreequipe1
pourcentage2=intermediaire*scoreequipe2

print ("L'équipe 1 a "poucentage1"% de chances de gagner le match.")
print ("L'équipe 2 a "poucentage2"% de chances de gagner le match.")
